let config = {
    host: 'sql12.freemysqlhosting.net',
    user: 'sql12268690',
    password: 'tzzuGiK3Kw',
    database: 'sql12268690'
}

/*let config = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mkm'
}*/

module.exports = config;