let config = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mkm'
}

module.exports = config;